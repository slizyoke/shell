look here:

http://blog.wangzhan.360.cn/?p=65


demo :

first you open webshell  is  "404", then enter "p", after show login page

pass: demo123456