# Younioner
Younioner is **multipale client** reverse shell created by Ayoub Ouakkaha, which is now under development

## How to use it
once you download the project(click on download zip button )
You can run this directly as python3 script 
* **windows**
just write the command below in command prompt
`python Server.py` 
to run Client just change Server.py with Client.py module:
`python Client.py`

* **Linux**
you can run this also inside linux OS using bellow commands
`python3 Server.py`
to run Client just change Server.py with Client.py module:
`python3 Client.py`

## Make it Executable:
instead of running python client.py every time we want to run the client module you can do this inside **windows** Using Py2Exe Library, after bellow proccess you will have .exe ready to run in anywhere without python, just follow me

1. download and install the library using this link [sourceforge](https://sourceforge.net/projects/py2exe/files/py2exe/0.6.9/)

2. with in command Prompt and inside the directory which you download the Younioner into run this command:
`python setup.py install`
3. that's it now you will be able to see dist folder just open it and you find **Client.exe** executable(its the one) 

To Do this Linux i only know one library that could get the job done which is **PyInstaller**, you can find more about this process using this link **[pythonhosted's website](https://pythonhosted.org/PyInstaller/)**

## Younioner Features
Younioner introduce tons of awesome Features, include:

1. **Multiple Client Support:** this is really important when you're Dealing with all of targets, this feature allow you to take control of each connected target in individual.
2. **Easy interface:**  up to this moment **Younioner** project uses terminal or command prompt in windows, we plan to switch to GUI(probably in incoming releases), anyway interface is really simple 
3. **Easy commands**: yes no more stupid and complicated commands, **Younioner** offers you easy and realistic commands  
4. **All Platforms :** Younioner support all different platforms which includes Mobile(tested on android), Windows, Linux, OS X...
5. **Under Developpement:** Younioner is under developpement which means a lot features are coming soon 

### so what is it Reverse Shell
A reverse shell is a type of shell in which the target machine communicates back to the attacking machine. The attacking machine has a listener port on which it receives the connection, which by using, code or command execution is achieved.

### get evolved with the project
we plan to make Younioner a great project, but this won't happen without a cooperation from other developers. 
so feel free to join us.. 

### Important
this project was made for security purposes.
you have no right to use this in any device other than yours 

### Contact Me
You can use this email to reach me **ayoub.ouakkaha@gmail.com**

**MADE WITH PASSION AND LOVE**
